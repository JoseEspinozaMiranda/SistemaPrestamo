<?php
	const SERVERURL="http://localhost/PRESTAMOS/";

	const COMPANY="SISTEMAS PRESTAMOS";

	const MONEDA="$";

	date_default_timezone_set("America/El_Salvador");