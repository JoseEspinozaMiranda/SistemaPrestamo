<!--=============================================
=            Include JavaScript files           =
==============================================-->
<!-- jQuery V3.4.1 -->
<script src="<?php echo SERVERURL; ?>vistas/js/jquery-3.4.1.min.js" ></script>

<!-- popper -->
<script src="<?php echo SERVERURL; ?>vistas/js/popper.min.js" ></script>

<!-- Bootstrap V4.3 -->
<script src="<?php echo SERVERURL; ?>vistas/js/bootstrap.min.js" ></script>

<!-- jQuery Custom Content Scroller V3.1.5 -->
<script src="<?php echo SERVERURL; ?>vistas/js/jquery.mCustomScrollbar.concat.min.js" ></script>

<!-- Bootstrap Material Design V4.0 -->
<script src="<?php echo SERVERURL; ?>vistas/js/bootstrap-material-design.min.js" ></script>
<script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>

<script src="<?php echo SERVERURL; ?>vistas/js/main.js" ></script>

<script src="<?php echo SERVERURL; ?>vistas/js/alertas.js" ></script>