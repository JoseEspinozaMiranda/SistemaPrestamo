<!-- Normalize V8.0.1 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/normalize.css">

<!-- Bootstrap V4.3 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/bootstrap.min.css">

<!-- Bootstrap Material Design V4.0 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/bootstrap-material-design.min.css">

<!-- Font Awesome V5.9.0 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/all.css">

<!-- Sweet Alerts V8.13.0 CSS file -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/sweetalert2.min.css">

<!-- Sweet Alert V8.13.0 JS file-->
<script src="<?php echo SERVERURL; ?>vistas/js/sweetalert2.min.js" ></script>

<!-- jQuery Custom Content Scroller V3.1.5 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/jquery.mCustomScrollbar.css">

<!-- General Styles -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/style.css">