<?php

	const SERVER="localhost";
	const DB="prestamo";
	const USER="root";
	const PASS="";

	const SGBD="mysql:host=".SERVER.";dbname=".DB;


	const METHOD="AES-256-CBC";
	const SECRET_KEY='$PRESTAMOS@2020';
	const SECRET_IV='037970';