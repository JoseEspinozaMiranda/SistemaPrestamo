<?php
	const SERVERURL="http://localhost/PRESTAMOS/";

	const COMPANY="SISTEMAS PRESTAMOS";

	const MONEDA="S/.";

	date_default_timezone_set("America/Lima");